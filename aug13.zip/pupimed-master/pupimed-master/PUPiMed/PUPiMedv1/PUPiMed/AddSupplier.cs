﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PUPiMed
{
    public partial class AddSupplier : MetroForm
    {
        public AddSupplier()
        {
            InitializeComponent();
        }

        private void lblAddress_Click(object sender, EventArgs e)
        {

        }

        private void txtCode_Click(object sender, EventArgs e)
        {

        }

        private void txtName_Click(object sender, EventArgs e)
        {

        }

        private void txtContactNo_Click(object sender, EventArgs e)
        {

        }

        private void txtEmailAdd_Click(object sender, EventArgs e)
        {

        }

        private void txtNumber_Click(object sender, EventArgs e)
        {

        }

        private void txtStreet_Click(object sender, EventArgs e)
        {

        }

        private void txtBarangay_Click(object sender, EventArgs e)
        {

        }

        private void txtCity_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void btncancel_Click(object sender, EventArgs e)
        {

        }
    }
}
