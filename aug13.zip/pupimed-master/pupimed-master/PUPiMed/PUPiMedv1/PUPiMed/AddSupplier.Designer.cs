﻿namespace PUPiMed
{
    partial class AddSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.status = new MetroFramework.Controls.MetroTile();
            this.formlbl = new MaterialSkin.Controls.MaterialLabel();
            this.txtEmailAdd = new MetroFramework.Controls.MetroTextBox();
            this.lblManuName = new MetroFramework.Controls.MetroLabel();
            this.txtStreet = new MetroFramework.Controls.MetroTextBox();
            this.lblother = new MetroFramework.Controls.MetroLabel();
            this.txtName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btncancel = new MetroFramework.Controls.MetroButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnAdd = new MetroFramework.Controls.MetroButton();
            this.suppcode = new MetroFramework.Controls.MetroLabel();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.txtContactNo = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.txtCity = new MetroFramework.Controls.MetroTextBox();
            this.txtBarangay = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.txtNumber = new MetroFramework.Controls.MetroTextBox();
            this.lblAddress = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // status
            // 
            this.status.ActiveControl = null;
            this.status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.status.BackColor = System.Drawing.Color.DarkCyan;
            this.status.Location = new System.Drawing.Point(-2, 74);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(597, 23);
            this.status.TabIndex = 54;
            this.status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.status.UseCustomBackColor = true;
            this.status.UseSelectable = true;
            // 
            // formlbl
            // 
            this.formlbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.formlbl.Depth = 0;
            this.formlbl.Font = new System.Drawing.Font("Roboto", 11F);
            this.formlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.formlbl.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.formlbl.Location = new System.Drawing.Point(-1, 5);
            this.formlbl.MouseState = MaterialSkin.MouseState.HOVER;
            this.formlbl.Name = "formlbl";
            this.formlbl.Size = new System.Drawing.Size(594, 78);
            this.formlbl.TabIndex = 55;
            this.formlbl.Text = "SUPPLIER";
            this.formlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtEmailAdd
            // 
            this.txtEmailAdd.AccessibleName = "";
            this.txtEmailAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmailAdd.BackColor = System.Drawing.Color.White;
            this.txtEmailAdd.Lines = new string[0];
            this.txtEmailAdd.Location = new System.Drawing.Point(334, 204);
            this.txtEmailAdd.MaxLength = 32767;
            this.txtEmailAdd.Name = "txtEmailAdd";
            this.txtEmailAdd.PasswordChar = '\0';
            this.txtEmailAdd.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtEmailAdd.SelectedText = "";
            this.txtEmailAdd.Size = new System.Drawing.Size(206, 23);
            this.txtEmailAdd.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtEmailAdd.TabIndex = 130;
            this.txtEmailAdd.UseCustomBackColor = true;
            this.txtEmailAdd.UseSelectable = true;
            this.txtEmailAdd.Click += new System.EventHandler(this.txtEmailAdd_Click);
            // 
            // lblManuName
            // 
            this.lblManuName.AccessibleName = "lblmed";
            this.lblManuName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblManuName.AutoSize = true;
            this.lblManuName.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblManuName.Location = new System.Drawing.Point(215, 204);
            this.lblManuName.Name = "lblManuName";
            this.lblManuName.Size = new System.Drawing.Size(111, 19);
            this.lblManuName.TabIndex = 129;
            this.lblManuName.Text = "Email Address :";
            // 
            // txtStreet
            // 
            this.txtStreet.AccessibleName = "";
            this.txtStreet.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtStreet.BackColor = System.Drawing.Color.White;
            this.txtStreet.Lines = new string[0];
            this.txtStreet.Location = new System.Drawing.Point(454, 264);
            this.txtStreet.MaxLength = 32767;
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.PasswordChar = '\0';
            this.txtStreet.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtStreet.SelectedText = "";
            this.txtStreet.Size = new System.Drawing.Size(86, 23);
            this.txtStreet.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtStreet.TabIndex = 116;
            this.txtStreet.UseCustomBackColor = true;
            this.txtStreet.UseSelectable = true;
            this.txtStreet.Click += new System.EventHandler(this.txtStreet_Click);
            // 
            // lblother
            // 
            this.lblother.AccessibleName = "lblother";
            this.lblother.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblother.AutoSize = true;
            this.lblother.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblother.Location = new System.Drawing.Point(215, 168);
            this.lblother.Name = "lblother";
            this.lblother.Size = new System.Drawing.Size(96, 19);
            this.lblother.TabIndex = 126;
            this.lblother.Text = "Contact No. :";
            // 
            // txtName
            // 
            this.txtName.AccessibleName = "";
            this.txtName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtName.Lines = new string[0];
            this.txtName.Location = new System.Drawing.Point(278, 130);
            this.txtName.MaxLength = 32767;
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.SelectedText = "";
            this.txtName.Size = new System.Drawing.Size(262, 23);
            this.txtName.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtName.TabIndex = 115;
            this.txtName.UseCustomBackColor = true;
            this.txtName.UseSelectable = true;
            this.txtName.Click += new System.EventHandler(this.txtName_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AccessibleName = "lblmed";
            this.metroLabel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(215, 130);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(57, 19);
            this.metroLabel1.TabIndex = 124;
            this.metroLabel1.Text = "Name :";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BackgroundImage = global::PUPiMed.Properties.Resources.cancel_teal_box;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(446, 378);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(26, 26);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 123;
            this.pictureBox2.TabStop = false;
            // 
            // btncancel
            // 
            this.btncancel.AccessibleName = "btncancel";
            this.btncancel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btncancel.BackColor = System.Drawing.Color.White;
            this.btncancel.Highlight = true;
            this.btncancel.Location = new System.Drawing.Point(441, 373);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(99, 37);
            this.btncancel.Style = MetroFramework.MetroColorStyle.Teal;
            this.btncancel.TabIndex = 121;
            this.btncancel.Text = "     Cancel";
            this.btncancel.UseCustomBackColor = true;
            this.btncancel.UseSelectable = true;
            this.btncancel.UseStyleColors = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::PUPiMed.Properties.Resources.add_teal_box;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(327, 378);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(26, 26);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 122;
            this.pictureBox1.TabStop = false;
            // 
            // btnAdd
            // 
            this.btnAdd.AccessibleName = "btnadd";
            this.btnAdd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAdd.Highlight = true;
            this.btnAdd.Location = new System.Drawing.Point(322, 373);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(99, 37);
            this.btnAdd.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnAdd.TabIndex = 120;
            this.btnAdd.Text = "   Save";
            this.btnAdd.UseCustomBackColor = true;
            this.btnAdd.UseSelectable = true;
            this.btnAdd.UseStyleColors = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // suppcode
            // 
            this.suppcode.AccessibleName = "suppcode";
            this.suppcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.suppcode.AutoSize = true;
            this.suppcode.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.suppcode.Location = new System.Drawing.Point(58, 314);
            this.suppcode.Name = "suppcode";
            this.suppcode.Size = new System.Drawing.Size(112, 19);
            this.suppcode.Style = MetroFramework.MetroColorStyle.Teal;
            this.suppcode.TabIndex = 133;
            this.suppcode.Text = "Supplier Code :";
            // 
            // txtCode
            // 
            this.txtCode.AccessibleName = "Eqcode";
            this.txtCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(38, 347);
            this.txtCode.MaxLength = 32767;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.Size = new System.Drawing.Size(151, 23);
            this.txtCode.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtCode.TabIndex = 132;
            this.txtCode.UseSelectable = true;
            this.txtCode.Click += new System.EventHandler(this.txtCode_Click);
            // 
            // txtContactNo
            // 
            this.txtContactNo.AccessibleName = "";
            this.txtContactNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtContactNo.BackColor = System.Drawing.Color.White;
            this.txtContactNo.Lines = new string[0];
            this.txtContactNo.Location = new System.Drawing.Point(317, 168);
            this.txtContactNo.MaxLength = 32767;
            this.txtContactNo.Name = "txtContactNo";
            this.txtContactNo.PasswordChar = '\0';
            this.txtContactNo.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtContactNo.SelectedText = "";
            this.txtContactNo.Size = new System.Drawing.Size(223, 23);
            this.txtContactNo.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtContactNo.TabIndex = 134;
            this.txtContactNo.UseCustomBackColor = true;
            this.txtContactNo.UseSelectable = true;
            this.txtContactNo.Click += new System.EventHandler(this.txtContactNo_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AccessibleName = "lbltype";
            this.metroLabel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(391, 264);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(57, 19);
            this.metroLabel2.TabIndex = 135;
            this.metroLabel2.Text = "Street :";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AccessibleName = "lbltype";
            this.metroLabel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(215, 298);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(91, 19);
            this.metroLabel3.TabIndex = 136;
            this.metroLabel3.Text = "Town/Brgy :";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AccessibleName = "lbltype";
            this.metroLabel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(215, 332);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(108, 19);
            this.metroLabel4.TabIndex = 137;
            this.metroLabel4.Text = "City/Province :";
            // 
            // txtCity
            // 
            this.txtCity.AccessibleName = "";
            this.txtCity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCity.BackColor = System.Drawing.Color.White;
            this.txtCity.Lines = new string[0];
            this.txtCity.Location = new System.Drawing.Point(329, 332);
            this.txtCity.MaxLength = 32767;
            this.txtCity.Name = "txtCity";
            this.txtCity.PasswordChar = '\0';
            this.txtCity.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCity.SelectedText = "";
            this.txtCity.Size = new System.Drawing.Size(211, 23);
            this.txtCity.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtCity.TabIndex = 138;
            this.txtCity.UseCustomBackColor = true;
            this.txtCity.UseSelectable = true;
            this.txtCity.Click += new System.EventHandler(this.txtCity_Click);
            // 
            // txtBarangay
            // 
            this.txtBarangay.AccessibleName = "";
            this.txtBarangay.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtBarangay.BackColor = System.Drawing.Color.White;
            this.txtBarangay.Lines = new string[0];
            this.txtBarangay.Location = new System.Drawing.Point(312, 298);
            this.txtBarangay.MaxLength = 32767;
            this.txtBarangay.Name = "txtBarangay";
            this.txtBarangay.PasswordChar = '\0';
            this.txtBarangay.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBarangay.SelectedText = "";
            this.txtBarangay.Size = new System.Drawing.Size(228, 23);
            this.txtBarangay.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtBarangay.TabIndex = 139;
            this.txtBarangay.UseCustomBackColor = true;
            this.txtBarangay.UseSelectable = true;
            this.txtBarangay.Click += new System.EventHandler(this.txtBarangay_Click);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AccessibleName = "lbltype";
            this.metroLabel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(215, 264);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(84, 19);
            this.metroLabel5.TabIndex = 140;
            this.metroLabel5.Text = "Building # :";
            // 
            // txtNumber
            // 
            this.txtNumber.AccessibleName = "";
            this.txtNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNumber.BackColor = System.Drawing.Color.White;
            this.txtNumber.Lines = new string[0];
            this.txtNumber.Location = new System.Drawing.Point(305, 264);
            this.txtNumber.MaxLength = 32767;
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.PasswordChar = '\0';
            this.txtNumber.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNumber.SelectedText = "";
            this.txtNumber.Size = new System.Drawing.Size(80, 23);
            this.txtNumber.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtNumber.TabIndex = 141;
            this.txtNumber.UseCustomBackColor = true;
            this.txtNumber.UseSelectable = true;
            this.txtNumber.Click += new System.EventHandler(this.txtNumber_Click);
            // 
            // lblAddress
            // 
            this.lblAddress.AccessibleName = "lbltype";
            this.lblAddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddress.AutoSize = true;
            this.lblAddress.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblAddress.Location = new System.Drawing.Point(215, 235);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(75, 19);
            this.lblAddress.TabIndex = 125;
            this.lblAddress.Text = "ADDRESS ";
            this.lblAddress.Click += new System.EventHandler(this.lblAddress_Click);
            // 
            // AddSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 441);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.txtNumber);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.txtBarangay);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.txtContactNo);
            this.Controls.Add(this.suppcode);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.txtEmailAdd);
            this.Controls.Add(this.lblManuName);
            this.Controls.Add(this.txtStreet);
            this.Controls.Add(this.lblother);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.status);
            this.Controls.Add(this.formlbl);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddSupplier";
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Teal;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTile status;
        private MaterialSkin.Controls.MaterialLabel formlbl;
        public MetroFramework.Controls.MetroTextBox txtEmailAdd;
        private MetroFramework.Controls.MetroLabel lblManuName;
        public MetroFramework.Controls.MetroTextBox txtStreet;
        private MetroFramework.Controls.MetroLabel lblother;
        public MetroFramework.Controls.MetroTextBox txtName;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private MetroFramework.Controls.MetroButton btncancel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroButton btnAdd;
        private MetroFramework.Controls.MetroLabel suppcode;
        public MetroFramework.Controls.MetroTextBox txtCode;
        public MetroFramework.Controls.MetroTextBox txtContactNo;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        public MetroFramework.Controls.MetroTextBox txtCity;
        public MetroFramework.Controls.MetroTextBox txtBarangay;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        public MetroFramework.Controls.MetroTextBox txtNumber;
        private MetroFramework.Controls.MetroLabel lblAddress;
    }
}